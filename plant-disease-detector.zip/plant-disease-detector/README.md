# 🌿 Plant Disease Detector — VGG16 + Telegram Alerts

An AI-powered desktop application that detects plant leaf diseases from uploaded images or a **real-time webcam feed**, using a custom-trained **VGG16 CNN model**. Provides disease name, confidence score, cure recommendations, and sends instant **Telegram alerts**.

---

## ✨ Features

- 🎯 **~89% classification accuracy** on test dataset
- 📷 **Two detection modes:** image upload OR live webcam (including IP webcam via Wi-Fi)
- 💊 **Cure/solution recommendations** per disease from a curated knowledge base
- 📲 **Telegram bot integration** — automatic alerts with prediction + photo
- 🖥️ **Tkinter GUI** — clean, intuitive desktop interface
- 🔍 Detects **6 disease categories** including healthy leaves

---

## 🦠 Supported Diseases

| Disease | Description |
|---|---|
| Bacterial Spot | Bacterial infection causing dark water-soaked spots |
| Early Blight | Fungal disease starting from lower leaves |
| Leaf Blight | Widespread leaf tissue death |
| Powdery Mildew | White powdery fungal coating |
| Rust | Orange-brown pustules on leaf surface |
| Healthy | No disease detected |

---

## 🛠️ Tech Stack

| Component | Technology |
|---|---|
| Deep Learning | TensorFlow / Keras — VGG16 (transfer learning) |
| Image Processing | OpenCV, Pillow |
| GUI | Tkinter |
| Notifications | Telegram Bot API (`telepot`) |
| Training | ImageDataGenerator with augmentation |

---

## 📁 Project Structure

```
plant-disease-detector/
├── nel.py                    # Main app — GUI + prediction logic
├── Training.py               # VGG16 training script
├── vgg16_trained_model.h5    # Trained model (not in repo — see below)
├── classification_report.txt # Model evaluation results
├── solutions/                # Disease cure text files
│   ├── Bacterial Spot.txt
│   ├── Early Blight.txt
│   ├── Leaf Blight.txt
│   ├── Powdery Mildew.txt
│   ├── Rust.txt
│   └── Healthy.txt
├── dataset/                  # Training images (not in repo)
│   ├── Bacterial Spot/
│   ├── Early Blight/
│   └── ...
└── requirements.txt
```

---

## ⚙️ Setup & Run

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/plant-disease-detector.git
cd plant-disease-detector
```

### 2. Install dependencies
```bash
pip install opencv-python==4.8.0.76 numpy==1.24.4 pillow requests tensorflow telepot
```

### 3. Configure Telegram Alerts (optional)
In `nel.py`, replace:
```python
BOT_TOKEN = "your-bot-token"
CHAT_ID   = "your-chat-id"
```
Get your bot token from [@BotFather](https://t.me/BotFather) on Telegram.

### 4. Run the app
```bash
python nel.py
```

> **Note:** `vgg16_trained_model.h5` (~500MB) is not included in this repo due to size limits. To retrain, run `Training.py` with the dataset placed in `./dataset/`.

---

## 🏋️ Training the Model

```bash
python Training.py
```

- Dataset: 1,000+ leaf images across 6 classes
- Architecture: VGG16 (ImageNet weights, top layers frozen) + custom Dense head
- Input size: 128×128 px
- Augmentation: rotation, zoom, flip, shear
- Epochs: 50 | Batch size: 128
- Optimizer: Adam | Loss: Categorical Crossentropy

---

## 📊 Model Performance

```
             precision    recall  f1-score   support
Bacterial S.    0.91       0.89     0.90       ...
Early Blight    0.87       0.88     0.87       ...
Leaf Blight     0.88       0.90     0.89       ...
Healthy         0.94       0.95     0.94       ...
...
Overall Accuracy: ~89%
```
See `classification_report.txt` for full details.

---

## 🔮 Future Improvements
- Expand to 30+ disease classes using PlantVillage dataset
- Mobile app version (TensorFlow Lite)
- REST API for web integration
- Real-time edge deployment on Raspberry Pi

---

## 👤 Author
**Vaishak S Iyengar**  
Information Science Engineering, BIET Davangere (VTU)  
[LinkedIn](https://www.linkedin.com/in/vaishak-siyengar-aa83312a2) · [Email](mailto:vaishak2303@gmail.com)
